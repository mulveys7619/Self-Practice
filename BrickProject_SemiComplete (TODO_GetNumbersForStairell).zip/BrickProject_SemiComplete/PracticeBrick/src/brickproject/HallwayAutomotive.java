package brickproject;
public class HallwayAutomotive 
{
    public static double brWide = 156.0;     //brick total from left to right
    public static double CalcMainPattern()
    {
        double brHeight = 30.0;              //brick total from top to bottom
        double main = brHeight * brWide;     //area of brick total
        return main;
    }
    public static double CalcTopPattern()
    {
        double brPerWide = 6.0;              //brick total from top to bottom for top brick
        double top = brPerWide * brWide;     //brick area for top brick
        return top;
    }
    public static double CalcBottomPattern()
    {
        double bottomPerBricks = 3.0;        //brick total from top to bottom for bottom brick
        double bottom = bottomPerBricks * brWide; //brick area for bottom brick
        return bottom;
    }
    public static double BrickTotal()
    {
        double total = CalcMainPattern() + CalcTopPattern()
                + CalcBottomPattern() + 8.0; //brick total added together
        return total;
    }
    
}
