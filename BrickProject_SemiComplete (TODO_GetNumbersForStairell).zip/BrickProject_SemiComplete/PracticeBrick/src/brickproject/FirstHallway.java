package brickproject;
public class FirstHallway {
    public static double brWide = 202.5;       //brick total from left to right
    public static double CalcMainPattern()
    {
        double brHeight = 30.0;                //brick total from top to bottom
        double main = brHeight * brWide;       //area of brick total
        return main;
    }
    public static double CalcTopPattern()
    {
        double brPerWide = 6.0;                 //brick total from top to bottom for top brick
        double top = brPerWide * brWide;        //brick area for top brick
        return top;
    }
    public static double CalcBottomPattern()
    {
        double bottomPerBricks = 3.0;          //brick total from top to bottom for bottom brick
        double bottom = bottomPerBricks * brWide; //brick area for bottom brick
        return bottom;
    }
    public static double CalcArchWay()
    {
        double archLength = 2.0;             //brick length for ceiling brick
        double archWidth = 9.0;              //brick width for ceiling brick
        double archTotal = archLength * archWidth; //area of ceiling brick
        return archTotal;
    }
    public static double BrickTotal()
    {
        double total = CalcMainPattern() + CalcTopPattern()
                + CalcBottomPattern() + CalcArchWay(); //brick total added together
        return total + 480; //brick total plus the two wall
    }
}
