/**
 * CSC-251
 * 11/23/2020
 * Je'Von Kent, Eugene Davis-Paulino, Sean Mulvey
 * This project will display the brick total and deduction of bricks not there
 */
package brickproject;
import javax.swing.JOptionPane;
public class BrickProject 
{
    /*
     We are done with the bricks part of the project once all the calculations
     are in then we will start the stairwell section the the lobby area and we
     can turn the project in.
    */
    public static void main(String[] args) 
    {
        double totalBricks = FirstHallway.BrickTotal() +
                SecondHallway.BrickTotal() + LobbyEntrance.BrickTotal()
                - DeductCalcs.NoneTotalBricks();
       JOptionPane.showMessageDialog(null,  "First Floor \n" + 
               "--------------- \n" + "First Long Hallway: " + 
               String.format("%.0f",FirstHallway.BrickTotal()) + 
               " bricks total\n" + "Second Long Hallway: "
               + String.format("%.0f",SecondHallway.BrickTotal())
               + " bricks total\n" + "Lobby Entrance: " +
               String.format("%.0f",LobbyEntrance.BrickTotal())
               + " bricks total\n" + "---------------\n" + 
               "Bricks that are filled with empty space"
               + "\n" + "----------------\n" + String.format("%.0f", 
               DeductCalcs.NoneTotalBricks()) + " for non-bricks\n" +
               "Total Bricks for Building\n" +
               String.format("%.0f", totalBricks) + " Bricks in Total");
    }
}
