package brickproject;
public class FirstShortHallway 
{
    public static double brWide = 138.0;
    public static double CalcMainPattern()
    {
        double brHeight = 30.0;
        double main = brHeight * brWide;
        return main;
    }
    public static double CalcTopPattern()
    {
        double brPerWide = 6.0;
        double top = brPerWide * brWide;
        return top;
    }
    public static double CalcBottomPattern()
    {
        double bottomPerBricks = 3.0;
        double bottom = bottomPerBricks * brWide;
        return bottom;
    }
    public static double BrickTotal()
    {
        double total = CalcMainPattern() + CalcTopPattern()
                + CalcBottomPattern(); //brick total added together
        return total;
    }
}
