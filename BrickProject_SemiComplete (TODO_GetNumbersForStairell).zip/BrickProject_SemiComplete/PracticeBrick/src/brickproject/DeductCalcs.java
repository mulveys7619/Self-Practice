package brickproject;
public class DeductCalcs {
    public static double AreaOfBrick()
    {
        double brLength = 7.65;                         //brick length
        double brWidth = 2.3;                           //brick width
        double areaOfBr = brLength * brWidth;           //area of brick
        return areaOfBr;
    }
    public static double AreaFourWindows()
    {
        double windowLength = 132.0;                        //window length
        double windowWidth = 88.0;                          //window width
        double areaOfWindow = windowLength * windowWidth;   //area of window
        return areaOfWindow;
    }
    public static double DoorFrameWithoutWind()
    {
        double doorFrameLen = 38.5;            // door without window length
        double doorFrameWid = 26.0;            // door without window width
        double areaOfDoorFrame =
            doorFrameLen * doorFrameWid * 19.0;   // area of door without window
        return areaOfDoorFrame;
    }
    public static double DoorFrameWithWindow()
    {
        double doorFrameLength = 64.5;         //door with window length   
        double doorFrameWidth = 88.0;          //door with window width
        double areaOfDoorFrame = 
            doorFrameLength * doorFrameWidth * 4;  //area of door with window
        return areaOfDoorFrame;
    }
    public static double Elevator()
    {
        double eleLength = 46.0;      //elevator length
        double eleWidth = 86.0;       //elevator width
        double areaOfElevator = 
            eleLength * eleWidth;     //area of elevator
        return areaOfElevator;
    }
    public static double DoubleDoorWithWindows()
    {
        double doubledoorLen = 131.4;         //double door with window length
        double doubledoorWid = 95.0;          //double door with window width
        double areaOfDoubleDoorWindow = 
            doubledoorLen * doubledoorWid;    //area of double door with window
        return areaOfDoubleDoorWindow; 
    }
    public static double DoubleDoors()
    {
        double doubleDoorLength = 38.5 * 2.0;  //entrance double door length
        double doubleDoorWidth = 88.0;         //entrance double door width
        //area of entrance double door
        double areaOfDouble = doubleDoorLength * doubleDoorWidth * 3.0;
        return areaOfDouble; 
    }
    public static double WindowsByAutomotive()
    {
        double windowsLength = 87.8;
        double windowsWidth = 93.5;
        double areaOfWindows = 
        windowsLength * windowsWidth * 4.0; // 4 window by the automotive door
        return areaOfWindows;
    }
    public static double AutomotiveDoubleDoor()
    {
        double automotiveLength = 73.8; //car shop double door length
        double automotiveWidth = 86.0;  //car shop double door width
        double areaOfAutomotive = 
            automotiveLength * automotiveWidth; //area of car shop double door
        return areaOfAutomotive;
    }
    public static double Vents()
    {
        double ventLength = 4.5;
        double ventWidth = 1.5;
        double areaOfVents = ventLength * ventWidth * 4.0;
        return areaOfVents;
    }
    public static double NoneTotalBricks()
    {
        double nonBricks = 
            (AreaFourWindows()+ DoorFrameWithoutWind() + 
            DoorFrameWithWindow()+ Elevator()+ DoubleDoorWithWindows()
            + DoubleDoors()+ WindowsByAutomotive() + AutomotiveDoubleDoor()) 
            / AreaOfBrick();
            //total of non bricks
        return nonBricks;
    }
}
