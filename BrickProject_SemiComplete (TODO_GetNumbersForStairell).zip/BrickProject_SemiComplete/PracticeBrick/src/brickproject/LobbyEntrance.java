package brickproject;
public class LobbyEntrance 
{
    /* 
    This will be the ;ast part of the project so don't worry about this right 
    now.
    */
    public static double CalcMainPattern()
    {
        double brHeight = 21.0;                //brick total from top to bottom
        double brWide = 30.0;
        double main = brHeight * brWide;       //area of brick total
        return main;
    }
    public static double CalcTopPattern()
    {
        double brPerWide = 6.0;                //brick total from top to bottom for top brick
        double brWide = 30.0;
        double top = brPerWide * brWide * 2.0;        //brick area for top brick
        return top;
    }
    public static double CalcBottomPattern()
    {
        double bottomPerBricks = 3.0;          //brick total from top to bottom for bottom brick
        double brWide = 30.0;
        double bottom = bottomPerBricks * brWide * 2.0; //brick area for bottom brick
        return bottom;
    }
    public static double CalcMidMainPattern()
    {
        double brLength = 32.0;
        double brWide = 21.0;
        double mid = brLength * brWide * 2.0;
        return mid;
    }
    public static double CalcMidTopPattern()
    {
        double brPerWide = 3.0;
        double brWide = 21.0;
        double midTop = brPerWide * brWide * 2.0;
        return midTop;
    }
    public static double TopMainPattern()
    {
        double brLength = 32.0;
        double brWide = 33.0;
        double topMain = brLength * brWide * 2.0;
        return topMain;
    }
    public static double VeryTopPattern()
    {
        double brPerWide = 6.0;
        double brWide = 33.0;
        double veryTop = brPerWide * brWide * 2.0;
        return veryTop;
    }
    public static double AboveArchways()
    {
        double brLength = 46.0;
        double brWide = 21.0;
        double aboveArch = brLength * brWide;
        return aboveArch;
    }
    public static double AboveBricksArchways()
    {
        double brPerWide = 3.0;
        double brWide = 21.0;
        double brickPerArch = brPerWide * brWide;
        return brickPerArch;
    }
    public static double PillarsAboveBricks()
    {
        double brLength = 2.0;
        double brWide = 21.0;
        double pillAbvBricks = brLength * brWide * 4.0;
        return pillAbvBricks;
    }
    public static double BrickTotal()
    {
        //brick total added together
        double total = CalcMainPattern() + CalcTopPattern()+ CalcBottomPattern()
                + CalcMidMainPattern() + CalcMidTopPattern() + 
                TopMainPattern() + VeryTopPattern() + AboveArchways()
                + AboveBricksArchways() + PillarsAboveBricks(); 
        return total;
    }
}
