
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package brickproject;
import java.lang.Math.*;

public class FrontAndBackStairwell {
    public static double GetTotalWallArea(double brickL, double brickH)
    {
        int brickR;
        int brickC;
        double wallL = brickR * brickL;
        double wallH = brickC * brickH;
        
        double area = wallL * wallH;
        return area;
    }
    public static double CircleArea(double diameter)
    {
        
        double radius = diameter / 2;
        double area = Math.PI * radius * radius;
        
        return area;
    }
    public static double GetAreaDiff(double brickA)
    {
        double diff = CircleArea("TODO: get outer") - CircleArea("TODO: Get inner");
        double bricksNeeded = diff / brickA;
        
        return bricksNeeded;
    }
    public static double GetTotalBricks(double brickA)
    {
        int CircleCenterLine = "TODO: Count Total bricks in center";
        double wallTotalA = GetTotalWallArea(7.65,2.3);
        double outerBricks = (walltotalA - CircleArea("TODO: Get Outer")) / brickA;
        double totalBricks = outerBricks + GetAreaDiff(brickA)+CircleCenterLine;
        return totalBricks;
    }
    
    
}
